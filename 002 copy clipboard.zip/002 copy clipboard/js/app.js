"use strict"
// copy section start here 

let copyText = document.querySelector('#copyText');
let copyBtn = document.querySelector('.copyBtn');

copyBtn.addEventListener('click',()=>{
	navigator.clipboard.writeText(copyText.value);
	alert('Copy Link to Clipboard')
})

// copy section ends here 

// cut section start here 

let cutText = document.querySelector('#cutText');
let cutBtn = document.querySelector('.cutBtn');

cutBtn.addEventListener('click',()=>{
	navigator.clipboard.writeText(cutText.value);
	cutText.value = '';
})

// cut section ends here 

// paste section start here 

let pasteInput = document.querySelector('#pasteInput');
let pasteBtn = document.querySelector('.pasteBtn');

pasteBtn.addEventListener('click',()=>{
	pasteInput.value = '';
	navigator.clipboard.readText()
	.then(function(pasteText){
		pasteInput.value = pasteText;
	})
	// cutText.value = '';
})

// paste section ends here 